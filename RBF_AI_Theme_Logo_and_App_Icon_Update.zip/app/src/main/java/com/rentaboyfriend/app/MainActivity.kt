package com.rentaboyfriend.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Person(val name:String,val age:Int,val city:String,val price:String,val rating:String,val services:String)
private val people = listOf(
    Person("Aarav Sharma",25,"Delhi, India","₹900/hr","4.9","Coffee dates • Reels • Photoshoots"),
    Person("Kabir Mehta",27,"Mumbai, India","₹1,200/hr","4.8","Events • Couple reels • Shopping"),
    Person("Ishaan Kapoor",24,"Jaipur, India","₹800/hr","4.7","Dance reels • Cafe visits • Acting"),
    Person("Oliver James",26,"London, UK","£18/hr","4.9","Travel reels • Photoshoots • Events"),
    Person("Haruto Sato",25,"Tokyo, Japan","¥2,500/hr","4.9","Street reels • Cafe visits • Photoshoots")
)
data class Palette(val id:String,val label:String,val bg:Color,val panel:Color,val accent:Color,val text:Color,val muted:Color)
private val palettes = listOf(
    Palette("red","White & Red",Color(0xFFFFFBFB),Color(0xFFFFFFFF),Color(0xFFC62828),Color(0xFF171717),Color(0xFF666666)),
    Palette("blue","White & Blue",Color(0xFFF8FBFF),Color(0xFFFFFFFF),Color(0xFF1769AA),Color(0xFF14202B),Color(0xFF657487)),
    Palette("blackblue","Black & Blue",Color(0xFF090E18),Color(0xFF151E2D),Color(0xFF3995FF),Color(0xFFF3F6FC),Color(0xFFA8B5C7)),
    Palette("gold","Black & Gold",Color(0xFF0B0B0D),Color(0xFF19191D),Color(0xFFD6AE58),Color(0xFFF4EBDD),Color(0xFFAAA5A0))
)
class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { RbfApp() }}
}
@Composable fun RbfApp(){
    val context= LocalContext.current
    var themeId by remember { mutableStateOf(context.getSharedPreferences("rbf",Context.MODE_PRIVATE).getString("theme","gold") ?: "gold") }
    val p=palettes.first{it.id==themeId}
    var tab by remember{mutableStateOf("Discover")}
    var page by remember{mutableStateOf("home")}
    var personIndex by remember{mutableIntStateOf(0)}
    var selected by remember{mutableStateOf<Person?>(null)}
    var loggedIn by remember{mutableStateOf(false)}
    var userName by remember{mutableStateOf("")}
    var email by remember{mutableStateOf("")}
    var password by remember{mutableStateOf("")}
    var service by remember{mutableStateOf("Reel making")}
    var duration by remember{mutableStateOf("2 hours")}
    var bookings by remember{mutableStateOf(listOf<String>())}
    var messages by remember{mutableStateOf(listOf("RBF AI support: Welcome! Ask us about bookings or reel services."))}
    var draft by remember{mutableStateOf("")}
    var paymentChoice by remember{mutableStateOf("Pay after confirmation")}
    MaterialTheme(colorScheme=if(p.id=="red"||p.id=="blue") lightColorScheme(primary=p.accent,background=p.bg,surface=p.panel,onSurface=p.text,onBackground=p.text) else darkColorScheme(primary=p.accent,background=p.bg,surface=p.panel,onSurface=p.text,onBackground=p.text)){
        Surface(Modifier.fillMaxSize(),color=p.bg){
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
                    val logoId = when(p.id){"red"->R.drawable.rbfai_logo_red;"blue"->R.drawable.rbfai_logo_blue;"blackblue"->R.drawable.rbfai_logo_blackblue;else->R.drawable.rbfai_logo_gold}
                    Image(painter=painterResource(logoId),contentDescription="RBF AI - Rent A Boyfriend Association of India",modifier=Modifier.weight(1f).height(58.dp),contentScale=ContentScale.Fit)
                    Text(if(loggedIn) "Hi, $userName" else "Guest",color=p.text,fontSize=12.sp)
                }
                when(page){
                    "login" -> LoginPage(p,email,{email=it},password,{password=it},userName,{userName=it}, {loggedIn=true;page="home"})
                    "profile" -> selected?.let { ProfilePage(it,p,{page="home"},{page="booking"}) }
                    "booking" -> BookingPage(p,service,{service=it},duration,{duration=it},paymentChoice,{paymentChoice=it},{page="home"},{ if(!loggedIn) page="login" else {bookings=bookings+"${selected?.name ?: "Creator"} • $service • $duration • $paymentChoice";page="home";tab="Bookings"} })
                    else -> {
                        when(tab){
                            "Discover" -> DiscoverPage(p,personIndex,{personIndex=(personIndex+1)%people.size},{personIndex=(personIndex-1+people.size)%people.size},{selected=it;page="profile"},{service=it;selected=null;page="booking"})
                            "Bookings" -> SimpleList(p,"MY BOOKINGS",bookings.ifEmpty{listOf("No bookings yet. Discover a creator to get started.")})
                            "Chat" -> ChatPage(p,messages,draft,{draft=it},{if(draft.isNotBlank()){messages=messages+("You: "+draft);draft=""}})
                            "Reels" -> ReelsPage(p,{service=it;selected=null;page="booking"})
                            else -> AccountPage(p,themeId,{themeId=it;context.getSharedPreferences("rbf",Context.MODE_PRIVATE).edit().putString("theme",it).apply()},loggedIn,{page="login"},{loggedIn=false;userName="";page="home"})
                        }
                        NavigationBar(containerColor=p.panel,contentColor=p.accent){
                            listOf("Discover","Bookings","Chat","Reels","Account").forEach { t ->
                                NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(when(t){"Discover"->Icons.Default.Search;"Bookings"->Icons.Default.CalendarMonth;"Chat"->Icons.Default.Chat;"Reels"->Icons.Default.VideoLibrary;else->Icons.Default.Person},contentDescription=t)},label={Text(t,fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=p.accent,selectedTextColor=p.accent,unselectedIconColor=p.muted,unselectedTextColor=p.muted,indicatorColor=p.accent.copy(alpha=.15f)))
                            }
                        }
                    }
                }
            }
        }
    }
}
@Composable fun DiscoverPage(p:Palette,index:Int,next:()->Unit,prev:()->Unit,open:(Person)->Unit,book:(String)->Unit){
    val person=people[index]
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{Text("YOUR NEXT GREAT PLUS-ONE.",fontSize=27.sp,fontWeight=FontWeight.Black,color=p.accent);Text("Companions, creators and reel partners — booked your way.",color=p.text)}
        item{
            Column(Modifier.fillMaxWidth().pointerInput(index){var total=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->total+=d},onDragEnd={if(total < -45) next() else if(total>45) prev();total=0f})}.background(p.panel,RoundedCornerShape(22.dp)).clickable{open(person)}.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(64.dp).background(p.accent.copy(alpha=.15f),RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center){Text(person.name.take(1),fontSize=30.sp,color=p.accent,fontWeight=FontWeight.Black)};Spacer(Modifier.width(14.dp));Column{Text("${person.name}, ${person.age}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=p.text);Text(person.city,color=p.muted);Text("★ ${person.rating} • ${person.price}",color=p.accent)}}
                Text(person.services,color=p.text)
                Text("Swipe left/right to browse • Tap to view profile",fontSize=11.sp,color=p.muted)
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(onClick=prev){Text("Previous")};Button(onClick=next,colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("Next",color=if(p.id.startsWith("white")) Color.White else Color.Black)}}
                Button(onClick={book("Companionship")},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("Book this creator",color=if(p.id=="red"||p.id=="blue") Color.White else Color.Black)}
            }
        }
        item{Text("FEATURED PROFILES",color=p.accent,fontWeight=FontWeight.Bold)}
        items(people){c->Card(Modifier.fillMaxWidth().clickable{open(c)},colors=CardDefaults.cardColors(containerColor=p.panel)){Column(Modifier.padding(15.dp)){Text("${c.name} • ${c.city}",color=p.text,fontWeight=FontWeight.Bold);Text("${c.services}  |  ★ ${c.rating}  |  ${c.price}",color=p.muted,fontSize=12.sp)}}}
        item{Text("Demo listings only. Real provider onboarding and identity checks are required before public launch.",color=p.muted,fontSize=11.sp)}
    }
}
@Composable fun ProfilePage(c:Person,p:Palette,back:()->Unit,book:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("‹ BACK",color=p.accent,modifier=Modifier.clickable{back()});Text(c.name,fontSize=28.sp,fontWeight=FontWeight.Black,color=p.text);Text("${c.city} • ${c.age} years • ★ ${c.rating}",color=p.accent);Text(c.services,color=p.text);Text("Services are arranged by prior agreement. Respect, consent and clear boundaries are required.",color=p.muted);Spacer(Modifier.weight(1f));Button(onClick=book,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("REQUEST BOOKING")}}}
@Composable fun BookingPage(p:Palette,service:String,setService:(String)->Unit,duration:String,setDuration:(String)->Unit,payment:String,setPayment:(String)->Unit,back:()->Unit,confirm:()->Unit){
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("‹ BACK",color=p.accent,modifier=Modifier.clickable{back()});Text("BOOK AN EXPERIENCE",fontSize=24.sp,color=p.accent,fontWeight=FontWeight.Black);Text("Choose service",color=p.text);listOf("Reel making","Coffee / dinner companion","Photoshoot","Event plus-one","Shopping companion").forEach{Row(Modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(12.dp)).clickable{setService(it)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(service==it,{setService(it)});Text(it,color=p.text)}};Text("Duration",color=p.text);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("1 hour","2 hours","4 hours").forEach{FilterChip(selected=duration==it,onClick={setDuration(it)},label={Text(it)})}};Text("Payment preference",color=p.text);listOf("Pay after confirmation","Online payment (not enabled in demo)").forEach{Row(verticalAlignment=Alignment.CenterVertically){RadioButton(payment==it,{setPayment(it)});Text(it,color=p.text,fontSize=13.sp)}};Spacer(Modifier.weight(1f));Button(onClick=confirm,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("SUBMIT BOOKING REQUEST")};Text("Demo mode: request is stored on this phone only. No payment is charged and no provider is contacted.",color=p.muted,fontSize=11.sp)}
}
@Composable fun LoginPage(p:Palette,email:String,setEmail:(String)->Unit,password:String,setPassword:(String)->Unit,name:String,setName:(String)->Unit,done:()->Unit){Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("CREATE ACCOUNT / SIGN IN",fontSize=23.sp,color=p.accent,fontWeight=FontWeight.Black);Text("Demo account only — authentication is stored locally for this session.",color=p.muted);OutField("Your name",name,setName,p);OutField("Email",email,setEmail,p);OutField("Password",password,setPassword,p,true);Button(onClick=done,enabled=name.isNotBlank()&&email.contains("@")&&password.length>=4,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("CONTINUE")}}}
@Composable fun OutField(label:String,value:String,onValue:(String)->Unit,p:Palette,secret:Boolean=false){Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Text(label,color=p.muted,fontSize=12.sp);if(secret){OutlinedTextField(value,onValue,singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())}else{OutlinedTextField(value,onValue,singleLine=true,modifier=Modifier.fillMaxWidth())}}}
@Composable fun ChatPage(p:Palette,messages:List<String>,draft:String,setDraft:(String)->Unit,send:()->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){Text("MESSAGES",fontSize=23.sp,color=p.accent,fontWeight=FontWeight.Black);LazyColumn(Modifier.weight(1f).fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=12.dp)){items(messages){Text(it,color=p.text,modifier=Modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(12.dp)).padding(13.dp))}};Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(draft,setDraft,modifier=Modifier.weight(1f),placeholder={Text("Write a message…")});IconButton(onClick=send){Icon(Icons.Default.Send,contentDescription="Send",tint=p.accent)}};Text("Demo chat is local only; live messaging requires a secure backend.",color=p.muted,fontSize=10.sp)}}
@Composable fun ReelsPage(p:Palette,book:(String)->Unit){LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("REEL-MAKING SERVICES",fontSize=23.sp,color=p.accent,fontWeight=FontWeight.Black);Text("Choose a creative service to request.",color=p.muted)};items(listOf("Couple-style reel","Travel / city reel","Dance reel","Product / lifestyle reel","Photoshoot + short video")){s->Card(colors=CardDefaults.cardColors(containerColor=p.panel)){Column(Modifier.padding(16.dp)){Text(s,color=p.text,fontWeight=FontWeight.Bold);Text("Discuss concept, duration and delivery before confirming.",color=p.muted,fontSize=12.sp);Button(onClick={book(s)},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text("Request this service")}}}}}}
@Composable fun SimpleList(p:Palette,title:String,rows:List<String>){Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(title,fontSize=23.sp,color=p.accent,fontWeight=FontWeight.Black);rows.forEach{Text(it,color=p.text,modifier=Modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(12.dp)).padding(15.dp))}}}
@Composable fun AccountPage(p:Palette,themeId:String,setTheme:(String)->Unit,logged:Boolean,login:()->Unit,logout:()->Unit){LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Text("ACCOUNT & SETTINGS",fontSize=23.sp,color=p.accent,fontWeight=FontWeight.Black);Text(if(logged)"Signed in (demo session)" else "You are browsing as a guest",color=p.text);Button(onClick=if(logged)logout else login,colors=ButtonDefaults.buttonColors(containerColor=p.accent)){Text(if(logged)"Sign out" else "Sign in / Create account")}};item{Text("CUSTOMISE YOUR THEME",color=p.accent,fontWeight=FontWeight.Bold)};items(palettes){choice->Row(Modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(12.dp)).clickable{setTheme(choice.id)}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(28.dp).background(choice.accent,RoundedCornerShape(8.dp)));Spacer(Modifier.width(12.dp));Text(choice.label,color=p.text,modifier=Modifier.weight(1f));RadioButton(themeId==choice.id,{setTheme(choice.id)})}};item{Text("Safety essentials",color=p.accent,fontWeight=FontWeight.Bold);Text("For a real launch, add verified adult users, consent and boundary policies, provider screening, emergency guidance, report/block tools, privacy controls and secure payment processing.",color=p.muted,fontSize=12.sp)};item{Text("This build is an interactive local prototype. Accounts, chat, booking storage and payments are not connected to a server.",color=p.muted,fontSize=11.sp)}}}
