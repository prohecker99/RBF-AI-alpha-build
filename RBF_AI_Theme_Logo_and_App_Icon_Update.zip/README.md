# RBF AI Android – Interactive Phone Prototype

This is an updated Kotlin + Jetpack Compose source project based on the supplied RentABoyfriendAndroid_Demo project.

## Added in this version
- Four selectable themes: White & Red, White & Blue, Black & Blue, Black & Gold. Theme choice is saved on the device with SharedPreferences.
- Touch-friendly bottom navigation and clickable profile/service cards.
- Swipe left/right on the featured Discover profile card to browse demo creators; Previous/Next buttons are also provided.
- Profile detail and booking-request flow with service, duration and payment-preference choices.
- Local demo sign-in/create-account form and session state.
- Local demo chat with send interaction.
- Reel service catalogue and booking entry points.
- Local booking list.

## Important limitations
This is an interactive local prototype, not a production-connected marketplace. Sign-in is not real authentication; chat is not delivered to another user; booking requests remain on this device; online payments are not enabled; and no identity checks or provider notifications occur. Real launch requires a secure backend, server-side authentication, database, verified adult-user onboarding, moderation/reporting, privacy controls, provider availability, and a payment provider integration. Do not collect real passwords or payment details in this prototype.

## Build
Open this folder in Android Studio and build `:app:assembleDebug`, or use a cloud Android build service that checks out the actual project files. The project uses the existing Gradle Kotlin DSL and Android Gradle Plugin configuration from the supplied source.


## Branding update
- Four theme-matched transparent RBF AI header logos switch with the selected in-app theme.
- Custom RBF AI gold-and-black Android launcher icon is configured for standard and round launcher icons.
- The launcher icon stays gold-and-black; the in-app header logo follows the selected theme.
