package com.rentaboyfriend.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF0B0B0D)
private val Panel = Color(0xFF19191D)
private val Gold = Color(0xFFD6AE58)
private val Cream = Color(0xFFF4EBDD)
private val Muted = Color(0xFFAAA5A0)

data class Creator(
    val name: String, val age: Int, val city: String, val price: String,
    val rating: String, val face: String, val build: String, val services: String
)

private val creators = listOf(
    Creator("Aarav Sharma", 25, "Delhi, India", "₹900/hr", "4.9", "Oval", "Athletic", "Coffee dates • Reels • Photoshoots"),
    Creator("Kabir Mehta", 27, "Mumbai, India", "₹1,200/hr", "4.8", "Square", "Lean", "Events • Couple reels • Shopping"),
    Creator("Ishaan Kapoor", 24, "Jaipur, India", "₹800/hr", "4.7", "Diamond", "Average", "Dance reels • Cafe visits • Acting"),
    Creator("Oliver James", 26, "London, UK", "£18/hr", "4.9", "Heart", "Slim", "Travel reels • Photoshoots • Events"),
    Creator("Ethan Brooks", 28, "New York, USA", "$25/hr", "4.8", "Square", "Athletic", "Lifestyle reels • Dinner companion"),
    Creator("Haruto Sato", 25, "Tokyo, Japan", "¥2,500/hr", "4.9", "Oval", "Lean", "Street-style reels • Cafe visits • Photoshoots"),
    Creator("Ren Nakamura", 23, "Osaka, Japan", "¥2,000/hr", "4.7", "Round", "Average", "Dance reels • City walks • Events")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RentApp() }
    }
}

@Composable
fun RentApp() {
    var tab by remember { mutableStateOf("Discover") }
    var selected by remember { mutableStateOf<Creator?>(null) }
    var showBooking by remember { mutableStateOf(false) }
    var booked by remember { mutableStateOf(false) }
    var rating by remember { mutableIntStateOf(5) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Black, surface = Panel, primary = Gold,
        onPrimary = Black, onBackground = Cream, onSurface = Cream
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            Column {
                Image(
                    painter = painterResource(id = R.drawable.rbfai_logo),
                    contentDescription = "RBF AI — Rent A Boyfriend Association of India",
                    modifier = Modifier.fillMaxWidth().height(126.dp).padding(horizontal = 14.dp, vertical = 8.dp)
                        .background(Color.White, RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Fit
                )
                if (selected != null) {
                    ProfileScreen(selected!!, onBack = { selected = null }, onBook = { showBooking = true })
                } else if (showBooking) {
                    BookingScreen(onBack = { showBooking = false }, onConfirm = { booked = true; showBooking = false })
                } else {
                    when (tab) {
                        "Discover" -> DiscoverScreen(onSelect = { selected = it })
                        "Bookings" -> BookingsScreen(booked)
                        "Reviews" -> ReviewsScreen(rating, onRating = { rating = it })
                        else -> AccountScreen()
                    }
                    NavigationBar(containerColor = Panel, contentColor = Gold) {
                        listOf("Discover", "Bookings", "Reviews", "Account").forEach { item ->
                            NavigationBarItem(
                                selected = tab == item, onClick = { tab = item },
                                icon = { Icon(when(item) {
                                    "Discover" -> Icons.Default.Search
                                    "Bookings" -> Icons.Default.CalendarMonth
                                    "Reviews" -> Icons.Default.Star
                                    else -> Icons.Default.Person
                                }, contentDescription = item) },
                                label = { Text(item, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Color(0xFF3A3020), unselectedIconColor = Muted, unselectedTextColor = Muted)
                            )
                        }
                    }
                }
            }
            if (booked) {
                AlertDialog(onDismissRequest = { booked = false }, confirmButton = {
                    TextButtonGold("Great", onClick = { booked = false })
                }, title = { Text("Request sent", color = Gold) },
                    text = { Text("Your demo booking request has been saved on this device.") },
                    containerColor = Panel)
            }
        }
    }
}

@Composable
fun DiscoverScreen(onSelect: (Creator) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(20.dp)) {
                Text("YOUR NEXT GREAT", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("PLUS-ONE.", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("Companions, creators and reel partners — booked your way.", color = Cream, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tag("REEL MAKING"); Tag("COMPANIONSHIP"); Tag("PHOTOSHOOTS")
                }
            }
        }
        item { Text("FEATURED COMPANIONS", color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
        items(creators) { creator -> CreatorCard(creator) { onSelect(creator) } }
        item { Text("All profiles are illustrative demo listings. Verify identity and availability before launching real bookings.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun CreatorCard(c: Creator, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onClick() }.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(62.dp).background(Color(0xFF393025), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Text(c.name.take(1), color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text("${c.name}, ${c.age}", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(c.city, color = Muted, fontSize = 12.sp)
                Text("★ ${c.rating}  •  ${c.price}", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text("VIEW  ›", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text(c.services, color = Cream, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Tag("Face: ${c.face}"); Tag("Build: ${c.build}") }
    }
}

@Composable
fun ProfileScreen(c: Creator, onBack: () -> Unit, onBook: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("‹  BACK", color = Gold, modifier = Modifier.clickable { onBack() })
        Box(Modifier.fillMaxWidth().height(155.dp).background(Color(0xFF302719), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Text(c.name.take(1), color = Gold, fontSize = 76.sp, fontWeight = FontWeight.Black)
        }
        Text("${c.name}, ${c.age}", color = Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("★ ${c.rating}  •  ${c.city}  •  ${c.price}", color = Gold)
        Text("ABOUT & STYLE", color = Gold, fontWeight = FontWeight.Bold)
        Text("Friendly, camera-ready and available for pre-agreed social activities and content creation.", color = Cream)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Tag("Face: ${c.face}"); Tag("Build: ${c.build}") }
        Text("SERVICES", color = Gold, fontWeight = FontWeight.Bold)
        Text(c.services, color = Cream)
        Spacer(Modifier.weight(1f))
        GoldButton("REQUEST A BOOKING", onBook)
    }
}

@Composable
fun BookingScreen(onBack: () -> Unit, onConfirm: () -> Unit) {
    var service by remember { mutableStateOf("Reel making") }
    var date by remember { mutableStateOf("Choose date with companion") }
    var duration by remember { mutableStateOf("2 hours") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("‹  BACK", color = Gold, modifier = Modifier.clickable { onBack() })
        Text("BOOK YOUR EXPERIENCE", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Select a service", color = Cream)
        listOf("Reel making", "Coffee / dinner companion", "Photoshoot", "Event plus-one", "Shopping companion").forEach {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).clickable { service = it }.padding(15.dp),
                verticalAlignment = Alignment.CenterVertically) {
                RadioButton(service == it, onClick = { service = it }, colors = RadioButtonDefaults.colors(selectedColor = Gold))
                Text(it, color = Cream)
            }
        }
        Text("Duration", color = Cream)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("1 hour", "2 hours", "4 hours").forEach { TagButton(it, duration == it) { duration = it } }
        }
        Text("Scheduling: $date", color = Muted, modifier = Modifier.clickable { date = "Date to be confirmed" })
        Spacer(Modifier.weight(1f))
        GoldButton("SEND BOOKING REQUEST", onConfirm)
        Text("Demo only: no payment is collected and no real booking is transmitted.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun BookingsScreen(booked: Boolean) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MY BOOKINGS", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        if (booked) Text("Booking request submitted • Awaiting confirmation", color = Cream)
        else Text("No bookings yet. Explore profiles to request your first experience.", color = Muted)
    }
}

@Composable
fun ReviewsScreen(rating: Int, onRating: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("RATINGS & REVIEWS", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Rate a completed booking", color = Cream)
        Row { (1..5).forEach { n ->
            IconButton(onClick = { onRating(n) }) { Icon(Icons.Default.Star, contentDescription = "$n stars",
                tint = if (n <= rating) Gold else Muted) }
        } }
        Text("$rating out of 5 stars", color = Gold, fontWeight = FontWeight.Bold)
        Text("Suggested review categories", color = Cream)
        listOf("Friendliness", "Punctuality", "Reel creativity", "Communication", "Overall experience").forEach { Tag(it) }
        Text("Only verified customers should be able to publish reviews in the live app.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("YOUR ACCOUNT", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Sign-in, identity verification, safety settings and creator onboarding will connect to the backend in the production version.", color = Cream)
        Tag("CUSTOMER & CREATOR ACCOUNTS")
        Tag("PROFILE VERIFICATION")
        Tag("REPORT & BLOCK")
        Tag("ADMIN SUPPORT")
    }
}

@Composable
fun Tag(text: String) {
    Text(text, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(Color(0xFF302719), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 7.dp))
}
@Composable
fun TagButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(text, color = if (selected) Black else Gold, modifier = Modifier
        .background(if (selected) Gold else Panel, RoundedCornerShape(50)).clickable { onClick() }.padding(12.dp))
}
@Composable
fun GoldButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black),
        shape = RoundedCornerShape(14.dp)) { Text(text, fontWeight = FontWeight.Black, letterSpacing = 1.sp) }
}
@Composable
fun TextButtonGold(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(text, color = Gold) }
}
