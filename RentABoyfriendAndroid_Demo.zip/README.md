# Rent A Boyfriend — Android starter app

A premium black-and-gold Android prototype built with Kotlin and Jetpack Compose.

## Included
- Discover screen with sample companion/creator profiles
- Profile details including self-described face shape and body build
- Service booking request flow for reel making, companionship, photoshoots and events
- Demo bookings screen
- Rating interaction and review categories
- Account/safety placeholder screen
- Black-and-gold visual theme

## Open in Android Studio
1. Install a current Android Studio version with Android SDK 35.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Run the `app` configuration on an emulator or Android device.

## Important prototype limits
This is a UI prototype. Sample profiles are fictional. Booking requests are local demo state only. There is no server, login, identity verification, real-time chat, payment gateway, location service, image upload, moderation console, or production booking workflow yet. Do not accept real payments or publish real profiles using this prototype.

## Before production
Add a secure backend and admin dashboard; age and identity verification; consent-based profile photos; secure chat; verified-booking reviews; payment provider integration; cancellation/refund rules; reporting/blocking; privacy policy and terms; and safeguards that enforce lawful, consensual, non-exploitative services. Physical meetups should have clear safety procedures. Face/body descriptors should be voluntary profile information, not automated attractiveness scores or biometric identification.


## Demo NPC profiles and supplied logo
The demo includes fictional NPC listings with Indian, English-speaking/international, and Japanese sample names (Aarav Sharma, Kabir Mehta, Ishaan Kapoor, Oliver James, Ethan Brooks, Haruto Sato, Ren Nakamura). The uploaded RBF AI / Rent A Boyfriend Association of India logo is included in the app header. These are test-only sample profiles, not real people or available service providers.
